package course.layers;

import course.layers.presentation.Console;

public class Application {

    public static void main(String[] args) {

        Console presentationObject = new Console();
        presentationObject.start();

    }

}
