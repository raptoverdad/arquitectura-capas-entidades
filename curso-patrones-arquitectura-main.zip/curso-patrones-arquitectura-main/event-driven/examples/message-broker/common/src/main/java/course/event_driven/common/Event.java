package course.event_driven.common;

/**
 * Interfaz bandera que todos los eventos del sistema deben implementar.
 * */
public interface Event {
}
