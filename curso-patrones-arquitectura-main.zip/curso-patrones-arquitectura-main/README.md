# Curso práctico de patrones de arquitectura

Ejemplo, talleres y demostraciones del curso práctico de patrones de arquitectura.
